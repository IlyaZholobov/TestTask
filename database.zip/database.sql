-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              11.0.0.5958
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных test
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `test`;

-- Дамп структуры для таблица test.city
CREATE TABLE IF NOT EXISTS `city` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Дамп данных таблицы test.city: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT IGNORE INTO `city` (`id`, `name`) VALUES
	(1, 'Киров'),
	(3, 'Уржум'),
	(4, 'Пермь');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;

-- Дамп структуры для таблица test.sight
CREATE TABLE IF NOT EXISTS `sight` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `id_city` int NOT NULL,
  `distance` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Дамп данных таблицы test.sight: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `sight` DISABLE KEYS */;
INSERT IGNORE INTO `sight` (`id`, `name`, `id_city`, `distance`) VALUES
	(1, 'Театральная площадь', 1, 0),
	(3, 'Цирк', 1, 2),
	(4, 'Озеро Шайтан', 3, 14),
	(5, 'Мемориальный Музей им. Кирова', 3, 10),
	(6, 'Уржумский краеведческий музей', 3, 3),
	(7, 'Дом Грибушина', 4, 2.5),
	(8, 'Легенда о пермском медведе', 4, 2),
	(9, 'Музей пермских древностей', 4, 3),
	(10, 'Пермский театр "У Моста"', 4, 1.2);
/*!40000 ALTER TABLE `sight` ENABLE KEYS */;

-- Дамп структуры для таблица test.traveler
CREATE TABLE IF NOT EXISTS `traveler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Дамп данных таблицы test.traveler: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `traveler` DISABLE KEYS */;
INSERT IGNORE INTO `traveler` (`id`, `name`) VALUES
	(1, 'Илья'),
	(2, 'Саша'),
	(3, 'Олег');
/*!40000 ALTER TABLE `traveler` ENABLE KEYS */;

-- Дамп структуры для таблица test.visit
CREATE TABLE IF NOT EXISTS `visit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_city` int NOT NULL,
  `id_sight` int NOT NULL,
  `id_traveler` int NOT NULL,
  `rating` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_city` (`id_city`),
  KEY `id_sight` (`id_sight`),
  KEY `id_traveler` (`id_traveler`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Дамп данных таблицы test.visit: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `visit` DISABLE KEYS */;
INSERT IGNORE INTO `visit` (`id`, `id_city`, `id_sight`, `id_traveler`, `rating`) VALUES
	(1, 1, 1, 1, 1),
	(2, 1, 1, 2, 3),
	(3, 1, 1, 3, 6),
	(4, 1, 3, 1, 3),
	(5, 1, 3, 2, 8),
	(6, 1, 3, 3, 10),
	(7, 3, 4, 1, 8),
	(8, 3, 4, 2, 9),
	(9, 3, 4, 3, 3),
	(10, 3, 5, 1, 7),
	(11, 3, 5, 2, 10),
	(12, 3, 5, 3, 4),
	(13, 3, 6, 1, 10),
	(14, 3, 6, 2, 1),
	(15, 3, 6, 3, 4),
	(16, 4, 7, 1, 7),
	(17, 4, 7, 2, 2),
	(18, 4, 7, 3, 8),
	(19, 4, 8, 1, 9),
	(20, 4, 8, 2, 4),
	(21, 4, 8, 3, 7),
	(22, 4, 9, 1, 2),
	(23, 4, 9, 2, 4),
	(24, 4, 9, 3, 4),
	(25, 4, 10, 1, 8),
	(26, 4, 10, 2, 4),
	(27, 4, 10, 3, 10);
/*!40000 ALTER TABLE `visit` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
